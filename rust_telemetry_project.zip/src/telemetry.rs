// Telemetry module placeholder
pub struct TelemetryCollector;
pub struct BleCompactPayload;

impl TelemetryCollector {
    pub fn new() -> Self {
        Self
    }
}
