use std::time::Duration;
use telemetry::{BleCompactPayload, TelemetryCollector};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{broadcast, mpsc, RwLock};
use tokio_tungstenite::accept_async;
use tokio_tungstenite::tungstenite::Message;
use uuid::Uuid;

#[cfg(windows)]
use windows::Win32::UI::WindowsAndMessaging::{GetForegroundWindow, GetWindowTextW};

// Custom 16-bit UUIDs for the Telemetry BLE GATT Service & Characteristic
const TELEMETRY_SERVICE_UUID: u16 = 0x181A; // Environmental / Telemetry Service
const TELEMETRY_CHAR_UUID: u16 = 0x2A3D;    // String / JSON Payload Characteristic

fn get_active_window_title() -> String {
    #[cfg(windows)]
    unsafe {
        let hwnd = GetForegroundWindow();
        if hwnd.is_invalid() {
            return "No Active Window".to_string();
        }

        let mut buffer: [u16; 512] = [0; 512];
        // Pass the mutable array as a mutable slice (&mut buffer[..])
        let len = GetWindowTextW(hwnd, &mut buffer[..]);
        
        if len <= 0 {
            return "No Active Window".to_string();
        }

        // Convert the valid wide-character slice into a Rust String safely
        String::from_utf16_lossy(&buffer[..len as usize])
    }
    #[cfg(not(windows))]
    {
        "Non-Windows Platform".to_string()
    }
}
