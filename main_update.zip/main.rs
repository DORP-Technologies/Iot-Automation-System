use windows_sys::Win32::UI::WindowsAndMessaging::{GetForegroundWindow, GetWindowTextW};

fn get_active_window_title() -> String {
    #[cfg(windows)]
    unsafe {
        let hwnd = GetForegroundWindow();
        if hwnd.is_invalid() {
            return "No Active Window".to_string();
        }

        let mut buffer = [0u16; 512];
        
        // Pass the raw mutable pointer and buffer length to the Win32 API
        let len = GetWindowTextW(hwnd, buffer.as_mut_ptr(), buffer.len() as i32);

        if len <= 0 {
            return "No Active Window".to_string();
        }

        // Safely borrow a slice of the array and convert to a Rust String
        String::from_utf16_lossy(&buffer[..len as usize])
    }

    #[cfg(not(windows))]
    {
        "Non-Windows Platform".to_string()
    }
}

fn main() {
    let window_title = get_active_window_title();
    println!("Active Window: {}", window_title);
}