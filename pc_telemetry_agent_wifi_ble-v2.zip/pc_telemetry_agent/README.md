# PC Telemetry Display Agent (Wi-Fi + BLE)

## Project Structure
- `Cargo.toml` — Dependencies (`windows` v0.54, `sysinfo`, `tokio`, `tokio-tungstenite`, `ble-peripheral-rust`, `serde`)
- `src/telemetry.rs` — System metrics collector (`TelemetryPayload` for Wi-Fi, `BleCompactPayload` for BLE)
- `src/main.rs` — Application entry point, Win32 active window title reader, WebSocket server, and BLE GATT peripheral

## Build Instructions
```bash
cargo build --release
```
Output executable: `target/release/pc_telemetry_agent.exe`
