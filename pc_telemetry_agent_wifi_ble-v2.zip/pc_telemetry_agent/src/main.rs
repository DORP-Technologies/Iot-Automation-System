mod telemetry;

use ble_peripheral_rust::{
    gatt::{
        characteristic::Characteristic,
        peripheral_event::{PeripheralEvent, ReadRequestResponse, RequestResponse},
        properties::{AttributePermission, CharacteristicProperty},
        service::Service,
    },
    uuid::ShortUuid,
    Peripheral, PeripheralImpl,
};
use futures_util::{SinkExt, StreamExt};
use std::net::SocketAddr;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::Duration;
use telemetry::{BleCompactPayload, TelemetryCollector, TelemetryPayload};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{broadcast, mpsc, RwLock};
use tokio_tungstenite::accept_async;
use tokio_tungstenite::tungstenite::Message;
use uuid::Uuid;

#[cfg(windows)]
use windows::Win32::UI::WindowsAndMessaging::{GetForegroundWindow, GetWindowTextW};

// Custom 16-bit UUIDs for the Telemetry BLE GATT Service & Characteristic
const TELEMETRY_SERVICE_UUID: u16 = 0x181A; // Environmental / Telemetry Service
const TELEMETRY_CHAR_UUID: u16 = 0x2A3D;    // String / JSON Payload Characteristic

fn get_active_window_title() -> String {
    #[cfg(windows)]
    unsafe {
        let hwnd = GetForegroundWindow();
        if hwnd.is_invalid() {
            return "No Active Window".to_string();
        }

        let mut buffer: [u16; 512] = [0; 512];
        // Safe slice API in windows v0.54+
        let len = GetWindowTextW(hwnd, &mut buffer);

        if len > 0 {
            let valid_len = (len as usize).min(buffer.len());
            // Explicit slice coercion resolves rust-analyzer(E0608)
            let slice: &[u16] = &buffer;
            return String::from_utf16_lossy(&slice[..valid_len]);
        } else {
            return "Unknown Window".to_string();
        }
    }
    #[cfg(not(windows))]
    {
        "Non-Windows Host".to_string()
    }
}

async fn handle_ws_client(
    stream: TcpStream,
    addr: SocketAddr,
    mut rx: broadcast::Receiver<String>,
) {
    println!("[WIFI/WS] Client connected: {}", addr);
    let ws_stream = match accept_async(stream).await {
        Ok(ws) => ws,
        Err(e) => {
            eprintln!("[WIFI/WS] Handshake failed for {}: {}", addr, e);
            return;
        }
    };

    let (mut write, mut read) = ws_stream.split();

    let read_task = tokio::spawn(async move {
        while let Some(msg) = read.next().await {
            if msg.is_err() {
                break;
            }
        }
    });

    while let Ok(payload_json) = rx.recv().await {
        if write.send(Message::Text(payload_json)).await.is_err() {
            break;
        }
    }

    read_task.abort();
    println!("[WIFI/WS] Client disconnected: {}", addr);
}

#[tokio::main]
async fn main() {
    let ws_bind_addr = "0.0.0.0:8765";
    let poll_interval_secs = 1.0_f64;

    // 1. Start Wi-Fi WebSocket Broadcast Server
    let (ws_tx, _ws_rx) = broadcast::channel::<String>(32);
    let ws_tx_clone = ws_tx.clone();

    tokio::spawn(async move {
        let listener = TcpListener::bind(ws_bind_addr)
            .await
            .expect("Failed to bind Wi-Fi WebSocket server");
        println!("[WIFI/WS] Listening on ws://{}", ws_bind_addr);

        while let Ok((stream, addr)) = listener.accept().await {
            let client_rx = ws_tx_clone.subscribe();
            tokio::spawn(handle_ws_client(stream, addr, client_rx));
        }
    });

    // 2. Start BLE GATT Peripheral Server
    let latest_ble_bytes = Arc::new(RwLock::new(b"{}".to_vec()));
    let ble_subscribed = Arc::new(AtomicBool::new(false));
    let (ble_event_tx, mut ble_event_rx) = mpsc::channel::<PeripheralEvent>(256);

    let ble_peripheral: Option<Peripheral> = match Peripheral::new(ble_event_tx).await {
        Ok(mut p) => {
            // Wait briefly for Windows Bluetooth adapter to confirm powered state
            let mut ready = false;
            for _ in 0..10 {
                if p.is_powered().await.unwrap_or(false) {
                    ready = true;
                    break;
                }
                tokio::time::sleep(Duration::from_millis(200)).await;
            }

            if ready {
                let service_uuid = Uuid::from_short(TELEMETRY_SERVICE_UUID);
                let char_uuid = Uuid::from_short(TELEMETRY_CHAR_UUID);

                let service = Service {
                    uuid: service_uuid,
                    primary: true,
                    characteristics: vec![Characteristic {
                        uuid: char_uuid,
                        properties: vec![
                            CharacteristicProperty::Read,
                            CharacteristicProperty::Notify,
                        ],
                        permissions: vec![AttributePermission::Readable],
                        value: None,
                        descriptors: vec![],
                    }],
                };

                if let Err(e) = p.add_service(&service).await {
                    eprintln!("[BLE] Failed to add GATT service: {:?}", e);
                }
                if let Err(e) = p.start_advertising("PC-Telemetry", &[service_uuid]).await {
                    eprintln!("[BLE] Failed to start advertising: {:?}", e);
                } else {
                    println!(
                        "[BLE] Advertising as 'PC-Telemetry' (Service: {:04X}, Char: {:04X})",
                        TELEMETRY_SERVICE_UUID, TELEMETRY_CHAR_UUID
                    );
                }
                Some(p)
            } else {
                eprintln!("[BLE] Bluetooth adapter is turned OFF. Continuing with Wi-Fi only.");
                None
            }
        }
        Err(e) => {
            eprintln!("[BLE] Could not initialize BLE peripheral: {:?}. Continuing with Wi-Fi only.", e);
            None
        }
    };

    // Spawn BLE event handler (handles client Read requests & Notify subscriptions)
    let latest_ble_reader = Arc::clone(&latest_ble_bytes);
    let ble_sub_flag = Arc::clone(&ble_subscribed);
    tokio::spawn(async move {
        while let Some(event) = ble_event_rx.recv().await {
            match event {
                PeripheralEvent::CharacteristicSubscriptionUpdate { subscribed, .. } => {
                    ble_sub_flag.store(subscribed, Ordering::SeqCst);
                    println!("[BLE] Client subscription updated: subscribed = {}", subscribed);
                }
                PeripheralEvent::ReadRequest { responder, .. } => {
                    let data = latest_ble_reader.read().await.clone();
                    let _ = responder.send(ReadRequestResponse {
                        value: data,
                        response: RequestResponse::Success,
                    });
                }
                _ => {}
            }
        }
    });

    // 3. Main Telemetry Collection & Dual-Transport Loop (Wi-Fi + BLE)
    let collector = Arc::new(tokio::sync::Mutex::new(TelemetryCollector::new()));
    let mut interval = tokio::time::interval(Duration::from_secs_f64(poll_interval_secs));

    println!("[AGENT] PC Telemetry Agent active (Wi-Fi + BLE). Press Ctrl+C to stop.");

    loop {
        interval.tick().await;

        let active_window = get_active_window_title();
        let payload: TelemetryPayload = {
            let mut guard = collector.lock().await;
            guard.collect(active_window, poll_interval_secs)
        };

        // Broadcast full JSON over Wi-Fi WebSocket
        if let Ok(full_json) = serde_json::to_string(&payload) {
            let _ = ws_tx.send(full_json);
        }

        // Update BLE GATT characteristic and notify subscribed ESP32-C3 / Android clients
        let compact = BleCompactPayload::from(&payload);
        if let Ok(compact_json) = serde_json::to_string(&compact) {
            let bytes = compact_json.into_bytes();
            {
                let mut guard = latest_ble_bytes.write().await;
                *guard = bytes.clone();
            }

            if let Some(ref p) = ble_peripheral {
                if ble_subscribed.load(Ordering::SeqCst) {
                    let char_uuid = Uuid::from_short(TELEMETRY_CHAR_UUID);
                    let _ = p.update_characteristic(char_uuid, bytes).await;
                }
            }
        }
    }
}
